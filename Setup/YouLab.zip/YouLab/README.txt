If you decide to install the program in a directory that requires administrator privileges 
you need to run the program as administrator otherwise it will not work correctly.

It is recommended to run YouLabSetup.msi to start the installation.